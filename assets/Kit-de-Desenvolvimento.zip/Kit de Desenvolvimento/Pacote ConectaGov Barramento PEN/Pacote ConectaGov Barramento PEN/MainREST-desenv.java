package br.gov.mp.pen.exemplocliente;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;

import org.apache.axis.encoding.Base64;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

import br.gov.planejamento.pen.interoperabilidade.soap.v1_1.tramite.DadosDoReciboDeTramite;

public class MainREST {

	private static final String URL_BASE = "https://pen-api.trafficmanager.net/interoperabilidade/rest/v1_1/";
	
	public static void main(String[] args) throws ClientProtocolException, IOException, KeyManagementException, KeyStoreException, NoSuchAlgorithmException, CertificateException, UnrecoverableKeyException, InvalidKeyException, SignatureException, DatatypeConfigurationException {
		
		// Trust own CA and all self-signed certs
		KeyStore keyStore = KeyStore.getInstance("pkcs12");
		KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
		keyStore.load(new FileInputStream("D:\\mp\\pen\\repositorio\\assets\\ssl\\pen-spe-teste-3.p12"), "changeit".toCharArray());
		trustStore.load(new FileInputStream("D:\\\mp\\pen\\repositorio\\assets\\ssl\\truststore-client.jks"), "changeit".toCharArray());
        SSLContext sslcontext = SSLContexts.custom()
            .loadTrustMaterial(trustStore, new TrustSelfSignedStrategy())
            .loadKeyMaterial(keyStore, "changeit".toCharArray())
            .build();
        // Allow TLSv1 protocol only
        SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(
            sslcontext,
            new String[] { "TLSv1" },
            null,
            new HostnameVerifier() {
				@Override
				public boolean verify(String hostname, SSLSession session) {
					// APENAS PARA TESTES LOCAIS,
					// N�O USE EM C�DIGO PRODUTIVO
					return true;
				}
			});
        CloseableHttpClient httpclient = HttpClients.custom()
            .setSSLSocketFactory(sslsf)
            .build();
        
		JSONObject respostaEnvio = enviaProcessoAdministrativo(httpclient);
		long ticket = respostaEnvio.getLong("ticketParaEnvioDeComponentesDigitais");
		long idt = respostaEnvio.getLong("IDT");
		
//		use para testar um ou mais passos intermedi�rios
//		long ticket = 4;
//		long idt = 4;

		uploadArquivoBinario(httpclient, ticket);
		downloadReciboEnvio(httpclient, idt);
		String nre = solicitaMetadados(httpclient, idt);
		downloadBinario(httpclient, idt);
		enviaReciboTramite(httpclient, idt, nre);
		downloadReciboTramite(httpclient, idt);
		
	}

	private static void downloadReciboTramite(CloseableHttpClient httpclient, long idt) throws ClientProtocolException, IOException {
		
		HttpGet httpGet = new HttpGet(URL_BASE + "/tramites/" + idt + "/recibo");
		
		CloseableHttpResponse response = httpclient.execute(httpGet);

		try {
		    System.out.println(response.getStatusLine());
		    
		    String strResponse = EntityUtils.toString(response.getEntity());
		    if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
		    	System.out.println("Download do recibo: " + strResponse);
		    } else {
		    	throw new RuntimeException(strResponse);
		    }
		    
		} finally {
		    response.close();
		}
		
	}

	private static void enviaReciboTramite(CloseableHttpClient httpclient, long idt, String nre) throws SignatureException, DatatypeConfigurationException, NoSuchAlgorithmException, KeyStoreException, CertificateException, FileNotFoundException, IOException, UnrecoverableKeyException, InvalidKeyException {
		
		Calendar agora = Calendar.getInstance();
		
		DadosDoReciboDeTramite dadosEnvio = new DadosDoReciboDeTramite();
		
		dadosEnvio.setIDT(idt);
		dadosEnvio.setDataDeRecebimento(DatatypeFactory.newInstance().newXMLGregorianCalendar((GregorianCalendar) agora));
		
		Signature signature = Signature.getInstance("SHA256withRSA");
		
		KeyStore keystore = KeyStore.getInstance("PKCS12");
		keystore.load(new FileInputStream("D:\\polisys\\mp\\pen\\repositorio\\assets\\ssl\\pen-spe-teste-3.p12"), "changeit".toCharArray());
		PrivateKey key = (PrivateKey) keystore.getKey("pen-spe-teste-3", "changeit".toCharArray());
		signature.initSign(key);
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

		// este passo � de EXTREMA import�ncia
		// para que a valida��o da assinatura
		// do lado do servidor ocorra corretamente
		format.setTimeZone(TimeZone.getTimeZone("UTC"));
		
		StringBuilder conteudoAsString = new StringBuilder();
		conteudoAsString.append("<recibo><IDT>");
		conteudoAsString.append(idt);
		conteudoAsString.append("</IDT><NRE>");
		conteudoAsString.append(nre);
		conteudoAsString.append("</NRE><dataDeRecebimento>");
		conteudoAsString.append(format.format(agora.getTime()));
		conteudoAsString.append("</dataDeRecebimento>");
		
		conteudoAsString.append("<hashDoComponenteDigital>gCLLk9xsjfSbuq5Or9GK6f8oSvv+eCQs2O7XObXLW50=</hashDoComponenteDigital>");
		
		conteudoAsString.append("</recibo>");
		byte[] conteudo = conteudoAsString.toString().getBytes();
		
		signature.update(conteudo);
		byte[] assinatura = signature.sign();
		dadosEnvio.setHashDaAssinatura(Base64.encode(assinatura));
		
		HttpPost httpPost = new HttpPost(URL_BASE + "/tramites/" + idt + "/recibo");
		httpPost.setHeader("Content-Type", "application/json");
		
		StringBuilder strRequest = new StringBuilder();
		strRequest.append("{");
		strRequest.append("    \"dataDeRecebimento\": \"" + format.format(agora.getTime()) + "\",");
		strRequest.append("    \"hashDaAssinatura\": \"" + Base64.encode(assinatura) + "\"");
		strRequest.append("}");
		httpPost.setEntity(new StringEntity(strRequest.toString()));
		
		CloseableHttpResponse response = httpclient.execute(httpPost);

		try {
		    System.out.println(response.getStatusLine());
		    
		    String strResponse = EntityUtils.toString(response.getEntity());
		    if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
		    	System.out.println("Envio do recibo de tr�mite.");
		    } else {
		    	throw new RuntimeException(strResponse);
		    }
		    
		} finally {
		    response.close();
		}
		
	}

	private static void downloadBinario(CloseableHttpClient httpclient, long idt) throws ClientProtocolException, IOException {
		
		HttpGet httpGet = new HttpGet(URL_BASE + "/tramites/" + idt + "/protocolos/123456/componentes-digitais/gCLLk9xsjfSbuq5Or9GK6f8oSvv+eCQs2O7XObXLW50=");
		
		CloseableHttpResponse response = httpclient.execute(httpGet);

		try {
		    System.out.println(response.getStatusLine());
		    
		    String strResponse = EntityUtils.toString(response.getEntity());
		    if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
		    	System.out.println("Componente digital: " + strResponse);
		    } else {
		    	throw new RuntimeException(strResponse);
		    }
		    
		} finally {
		    response.close();
		}
		
	}

	private static String solicitaMetadados(CloseableHttpClient httpclient, long idt) throws ClientProtocolException, IOException {
		
		HttpGet httpGet = new HttpGet(URL_BASE + "/tramites/" + idt);
		
		CloseableHttpResponse response = httpclient.execute(httpGet);

		try {
		    System.out.println(response.getStatusLine());
		    
		    String strResponse = EntityUtils.toString(response.getEntity());
		    if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
		    	System.out.println("Metadados: " + strResponse);
		    	JSONObject jsonObject = new JSONObject(strResponse);
		    	return jsonObject.getString("nre");
		    } else {
		    	throw new RuntimeException(strResponse);
		    }
		    
		} finally {
		    response.close();
		}
	}

	private static void downloadReciboEnvio(CloseableHttpClient httpclient, long idt) throws ClientProtocolException, IOException {
		
		HttpGet httpGet = new HttpGet(URL_BASE + "/tramites/" + idt + "/recibo-de-envio");
		
		CloseableHttpResponse response = httpclient.execute(httpGet);

		try {
		    System.out.println(response.getStatusLine());
		    
		    String strResponse = EntityUtils.toString(response.getEntity());
		    if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
		    	System.out.println("Download do recibo de envio: " + strResponse);
		    } else {
		    	throw new RuntimeException(strResponse);
		    }
		    
		} finally {
		    response.close();
		}
		
	}

	private static void uploadArquivoBinario(CloseableHttpClient httpclient, long ticket) throws ClientProtocolException, IOException {
		
		HttpPut httpPut = new HttpPut(URL_BASE + "/tickets-de-envio-de-componente/" + ticket + "/protocolos/123456/componentes-a-enviar/gCLLk9xsjfSbuq5Or9GK6f8oSvv+eCQs2O7XObXLW50=");
		
		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		builder.addBinaryBody("conteudo", new File("D:\\polisys\\mp\\pen\\repositorio\\doc\\binariosparateste\\binario1.txt"));
		httpPut.setEntity(builder.build());
		
		CloseableHttpResponse response = httpclient.execute(httpPut);

		try {
		    System.out.println(response.getStatusLine());
		    
		    String strResponse = EntityUtils.toString(response.getEntity());
		    if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
		    	System.out.println("Upload do arquivo bin�rio.");
		    } else {
		    	throw new RuntimeException(strResponse);
		    }
		    
		} finally {
		    response.close();
		}
		
	}

	private static JSONObject enviaProcessoAdministrativo(CloseableHttpClient httpclient) throws ClientProtocolException, IOException {
		
		HttpPost httpPost = new HttpPost(URL_BASE + "/tramites/processo");
		httpPost.setHeader("Content-Type", "application/json");
		
		StringBuilder strRequest = new StringBuilder();
		strRequest.append("{");
		strRequest.append("    \"cabecalho\": {");
		strRequest.append("        \"remetente\": {");
		strRequest.append("            \"identificacaoDoRepositorioDeEstruturas\": \"2\",");
		strRequest.append("            \"numeroDeIdentificacaoDaEstrutura\": \"42602\"");
		strRequest.append("        },");
		strRequest.append("        \"destinatario\": {");
		strRequest.append("            \"identificacaoDoRepositorioDeEstruturas\": \"2\",");
		strRequest.append("            \"numeroDeIdentificacaoDaEstrutura\": \"115046\"");
		strRequest.append("        },");
		strRequest.append("        \"obrigarEnvioDeTodosOsComponentesDigitais\": true");
		strRequest.append("    },");
		strRequest.append("    \"processo\": {");
		strRequest.append("        \"protocolo\": \"123456\",");
		strRequest.append("        \"nivelDeSigilo\": 1,");
		strRequest.append("        \"produtor\": {");
		strRequest.append("            \"nome\": \"Minist�rio ABC\",");
		strRequest.append("            \"tipo\": \"orgaopublico\"");
		strRequest.append("        },");
		strRequest.append("        \"descricao\": \"Descri��o ABC\",");
		strRequest.append("        \"dataHoraDeProducao\": \"2014-06-01T14:30:00-03:00\",");
		strRequest.append("        \"dataHoraDeRegistro\": \"2014-06-01T14:30:00-03:00\",");
		strRequest.append("        \"documentos\": [");
		strRequest.append("            {");
		strRequest.append("                \"ordem\": 1,");
		strRequest.append("                \"nivelDeSigilo\": 1,");
		strRequest.append("                \"produtor\": {");
		strRequest.append("                    \"nome\": \"Minist�rio ABC\",");
		strRequest.append("                    \"tipo\": \"orgaopublico\"");
		strRequest.append("                },");
		strRequest.append("                \"descricao\": \"Descri��o ABC\",");
		strRequest.append("                \"dataHoraDeProducao\": \"2014-06-01T14:30:00-03:00\",");
		strRequest.append("                \"dataHoraDeRegistro\": \"2014-06-01T14:30:00-03:00\",");
		strRequest.append("                \"especie\": {");
		strRequest.append("                    \"codigo\": \"52\",");
		strRequest.append("                    \"nomeNoProdutor\": \"Esp�cie ABC\"");
		strRequest.append("                },");
		strRequest.append("                \"componentesDigitais\": [");
		strRequest.append("                    {");
		strRequest.append("                        \"nome\": \"Componente ABC 1\",");
		strRequest.append("                        \"hash\": {");
		strRequest.append("                            \"algoritmo\": \"SHA256\",");
		strRequest.append("                            \"conteudo\": \"gCLLk9xsjfSbuq5Or9GK6f8oSvv+eCQs2O7XObXLW50=\"");
		strRequest.append("                        },");
		strRequest.append("                        \"tipoDeConteudo\": \"txt\",");
		strRequest.append("                        \"mimeType\": \"text/plain\",");
		strRequest.append("                        \"tamanhoEmBytes\": 42,");
		strRequest.append("                        \"ordem\": 1");
		strRequest.append("                    }");
		strRequest.append("                ]");
		strRequest.append("            }");
		strRequest.append("        ],");
		strRequest.append("        \"interessados\": [");
		strRequest.append("            {");
		strRequest.append("                \"nome\": \"Pessoa ABC\"");
		strRequest.append("            }");
		strRequest.append("        ]");
		strRequest.append("    }");
		strRequest.append("}");
		httpPost.setEntity(new StringEntity(strRequest.toString()));
		
		CloseableHttpResponse response = httpclient.execute(httpPost);

		try {
		    System.out.println(response.getStatusLine());
		    
		    String strResponse = EntityUtils.toString(response.getEntity());
		    if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
		    	System.out.println("Envio do processo: " + strResponse);
		    	JSONObject jsonObject = new JSONObject(strResponse);
		    	return jsonObject;
		    } else {
		    	throw new RuntimeException(strResponse);
		    }
		    
		} finally {
		    response.close();
		}
		
	}
	
}
