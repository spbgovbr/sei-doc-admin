package br.gov.mp.pen.exemplocliente;

import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.net.URL;
import java.rmi.RemoteException;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Signature;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.activation.DataHandler;
import javax.mail.util.ByteArrayDataSource;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import org.apache.axis.encoding.Base64;

import br.gov.planejamento.pen.interoperabilidade.v1.InteroperabilidadeException_Exception;
import br.gov.planejamento.pen.interoperabilidade.v1.InteroperabilidadePEN;
import br.gov.planejamento.pen.interoperabilidade.v1.componente_digital.ComponenteDigital;
import br.gov.planejamento.pen.interoperabilidade.v1.componente_digital.Hash;
import br.gov.planejamento.pen.interoperabilidade.v1.componente_digital.MimeType;
import br.gov.planejamento.pen.interoperabilidade.v1.componente_digital.TipoDeConteudo;
import br.gov.planejamento.pen.interoperabilidade.v1.comum.Especie;
import br.gov.planejamento.pen.interoperabilidade.v1.comum.EstruturaOrganizacional;
import br.gov.planejamento.pen.interoperabilidade.v1.comum.Interessado;
import br.gov.planejamento.pen.interoperabilidade.v1.comum.Produtor;
import br.gov.planejamento.pen.interoperabilidade.v1.documento.DocumentoDoProcesso;
import br.gov.planejamento.pen.interoperabilidade.v1.processo.Processo;
import br.gov.planejamento.pen.interoperabilidade.v1.tramite.ConteudoDoReciboDeEnvio;
import br.gov.planejamento.pen.interoperabilidade.v1.tramite.ConteudoDoReciboDeTramite;
import br.gov.planejamento.pen.interoperabilidade.v1.tramite.DadosDoComponenteDigital;
import br.gov.planejamento.pen.interoperabilidade.v1.tramite.DadosDoReciboDeTramite;
import br.gov.planejamento.pen.interoperabilidade.v1.tramite.DadosTramiteDeProcessoCriado;
import br.gov.planejamento.pen.interoperabilidade.v1.tramite.IdentificacaoDoComponenteDigital;
import br.gov.planejamento.pen.interoperabilidade.v1.tramite.Metadados;
import br.gov.planejamento.pen.interoperabilidade.v1.tramite.NovoTramiteDeProcesso;
import br.gov.planejamento.pen.interoperabilidade.v1.tramite.NovoTramiteDeProcesso.Cabecalho;

public class MainGuiaUtilizacao {

	/**
	 * Alias do par de chaves dentro
	 * do KeyStore JKS.
	 */
	private static final String KEY_ALIAS = "key-alias";

	/**
	 * Caminho do WSDL do ambiente desejado.
	 */
	private static final String WSDL_PATH = "https://999.999.999.999/pen/soap/?wsdl";

	/**
	 * Senha do keystore que cont�m o par
	 * de chaves autorizado a acessar o ambiente.
	 */
	private static final String KEYSTORE_PASSWORD = "changeit";

	/**
	 * Caminho onde se encontra o keystore JKS
	 * que cont�m o par de chaves autorizado
	 * a acessar o ambiente. 
	 */
	private static final String KEYSTORE_PATH = "caminho/absoluto/para/keystore.p12";

	/**
	 * Caminho onde se encontra o truststore JKS
	 * que cont�m o certificado do servidor.
	 */
	private static final String TRUSTSTORE_PATH = "caminho/absoluto/para/truststore.jks";

	public static void main(String[] args) {
		
		System.setProperty("javax.net.ssl.trustStore", TRUSTSTORE_PATH);
		
		// java.net.SocketException: Software caused connection abort: recv failed
		// significa que o aplicativo n�o est� enviando sua pr�pria chave!
		System.setProperty("javax.net.ssl.keyStoreType", "pkcs12");
		System.setProperty("javax.net.ssl.keyStore", KEYSTORE_PATH);
		System.setProperty("javax.net.ssl.keyStorePassword", KEYSTORE_PASSWORD);
		
		try {
			
			URL url = new URL(WSDL_PATH);
			
			QName qname = new QName("http://pen.planejamento.gov.br/interoperabilidade/v1", "InteroperabilidadePENService");
			
			Service service = Service.create(url, qname);
			InteroperabilidadePEN ws = service.getPort(InteroperabilidadePEN.class);

			DadosTramiteDeProcessoCriado respostaEnvio = envioProcessoAdministrativo(ws);

			long ticket = respostaEnvio.getTicketParaEnvioDeComponentesDigitais();
			long idt = respostaEnvio.getIDT();

			uploadArquivoBinario(ws, ticket);
			downloadReciboEnvio(ws, idt);
			String nre = solicitaMetadados(ws, idt);
			downloadBinario(ws, idt);
			enviaReciboTramite(ws, idt, nre);
			downloadReciboTramite(ws, idt);
			
		} catch (InteroperabilidadeException_Exception e) {
			System.out.println("C�digo do erro: " + e.getFaultInfo().getCodigoErro());
			System.out.println("Mensagem de erro: " + e.getFaultInfo().getMensagem());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	private static void downloadReciboEnvio(InteroperabilidadePEN ws, long idt) throws InteroperabilidadeException_Exception {
		
		ConteudoDoReciboDeEnvio reciboDeEnvio = ws.receberReciboDeEnvio(idt);
		
		System.out.println("Data do recibo de envio: " + reciboDeEnvio.getReciboDeEnvio().getDataDeRecebimentoDoUltimoComponenteDigital());
		
	}

	private static void downloadReciboTramite(InteroperabilidadePEN ws, long idt) throws InteroperabilidadeException_Exception {
		
		ConteudoDoReciboDeTramite recibo = ws.receberReciboDeTramite(idt);
		
		System.out.println("Download do recibo efetuado com sucesso! Data de recebimento: " + recibo.getRecibo().getDataDeRecebimento());
		
	}

	private static void enviaReciboTramite(InteroperabilidadePEN ws, long idt, String nre) throws Exception {

		Calendar agora = Calendar.getInstance();
		
		DadosDoReciboDeTramite dadosEnvio = new DadosDoReciboDeTramite();
		
		dadosEnvio.setIDT(idt);
		dadosEnvio.setDataDeRecebimento(DatatypeFactory.newInstance().newXMLGregorianCalendar((GregorianCalendar) agora));
		
		Signature signature = Signature.getInstance("SHA256withRSA");
		
		KeyStore keystore = KeyStore.getInstance("PKCS12");
		keystore.load(new FileInputStream(KEYSTORE_PATH), KEYSTORE_PASSWORD.toCharArray());
		PrivateKey key = (PrivateKey) keystore.getKey(KEY_ALIAS, KEYSTORE_PASSWORD.toCharArray());
		signature.initSign(key);
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		StringBuilder conteudoAsString = new StringBuilder();
		conteudoAsString.append("<recibo><IDT>");
		conteudoAsString.append(idt);
		conteudoAsString.append("</IDT><NRE>");
		conteudoAsString.append(nre);
		conteudoAsString.append("</NRE><dataDeRecebimento>");
		conteudoAsString.append(format.format(agora.getTime()));
		conteudoAsString.append("</dataDeRecebimento>");
		
		conteudoAsString.append("<hashDoComponenteDigital>l9G0iRAn39p9HM9idu/C8tiZMV5LmmLOoS8N/0SbNHs=</hashDoComponenteDigital>");
		
		conteudoAsString.append("</recibo>");
		byte[] conteudo = conteudoAsString.toString().getBytes();
		
		signature.update(conteudo);
		byte[] assinatura = signature.sign();
		dadosEnvio.setHashDaAssinatura(assinatura);
		
		ws.enviarReciboDeTramite(dadosEnvio);
		
		System.out.println("Recibo de tr�mite enviado com sucesso!");
		
	}

	private static void downloadBinario(InteroperabilidadePEN ws, long idt) throws InteroperabilidadeException_Exception, IOException {

		IdentificacaoDoComponenteDigital dadosDownload = new IdentificacaoDoComponenteDigital();
		dadosDownload.setIDT(idt);
		dadosDownload.setProtocolo("15900032647");
		
		dadosDownload.setHashDoComponenteDigital(Base64.decode("l9G0iRAn39p9HM9idu/C8tiZMV5LmmLOoS8N/0SbNHs="));
		
		DataHandler arquivoBinario = ws.receberComponenteDigital(dadosDownload);
		System.out.print("Conte�do do download: \"");
		arquivoBinario.writeTo(System.out);
		System.out.println("\"");
		
	}

	private static String solicitaMetadados(InteroperabilidadePEN ws,
			long idt) throws InteroperabilidadeException_Exception, RemoteException {
		
		Metadados metadados = ws.solicitarMetadados(idt);
		
		System.out.println("Protocolo retornado nos metadados: " + metadados.getProcesso().getProtocolo());
		
		return metadados.getNRE();
		
	}

	private static void uploadArquivoBinario(InteroperabilidadePEN ws, long ticket) throws InteroperabilidadeException_Exception, RemoteException {
		
		DadosDoComponenteDigital dadosUpload = new DadosDoComponenteDigital();
		dadosUpload.setTicketParaEnvioDeComponentesDigitais(ticket);
		dadosUpload.setHashDoComponenteDigital(Base64.decode("l9G0iRAn39p9HM9idu/C8tiZMV5LmmLOoS8N/0SbNHs="));
		dadosUpload.setProtocolo("15900032647");
		dadosUpload.setConteudoDoComponenteDigital(new DataHandler(new ByteArrayDataSource("Conte�do teste".getBytes(), "text/plain")));
		
		ws.enviarComponenteDigital(dadosUpload);
		
		System.out.println("Upload executado com sucesso!");
		
	}

	private static DadosTramiteDeProcessoCriado envioProcessoAdministrativo(InteroperabilidadePEN ws)
			throws RemoteException, InteroperabilidadeException_Exception, DatatypeConfigurationException {
		
		NovoTramiteDeProcesso dadosEnvio = new NovoTramiteDeProcesso();
		
		Cabecalho cabecalho = new Cabecalho();
		
//		use esta chave para desligar o tratamento
//		da solu��o que verifica se um ou mais
//		componentes digitais j� foram enviados
//		para o SPE de destino.
		cabecalho.setObrigarEnvioDeTodosOsComponentesDigitais(true);
		
//		use este valor para tramitar um
//		processo ou documento que j� 
//		passou alguma vez pela solu��o
//		cabecalho.setNRE("0000000142722014");
		
		EstruturaOrganizacional orgaoRemetente = new EstruturaOrganizacional();
		orgaoRemetente.setIdentificacaoDoRepositorioDeEstruturas("001");
		orgaoRemetente.setNumeroDeIdentificacaoDaEstrutura("0025");
		cabecalho.setRemetente(orgaoRemetente);
		
		EstruturaOrganizacional orgaoDestinatario = new EstruturaOrganizacional();
		orgaoDestinatario.setIdentificacaoDoRepositorioDeEstruturas("001");
		orgaoDestinatario.setNumeroDeIdentificacaoDaEstrutura("0050");
		cabecalho.setDestinatario(orgaoDestinatario);

		dadosEnvio.setCabecalho(cabecalho);
		
		Processo processo = new Processo();
		dadosEnvio.setProcesso(processo);

		processo.setProtocolo("15900032647");
		processo.setDataHoraDeProducao(DatatypeFactory.newInstance().newXMLGregorianCalendar((GregorianCalendar) Calendar.getInstance()));
		processo.setDataHoraDeRegistro(DatatypeFactory.newInstance().newXMLGregorianCalendar((GregorianCalendar) Calendar.getInstance()));
		processo.setNivelDeSigilo(BigInteger.ONE);
		
		Produtor produtor = new Produtor();
		produtor.setTipo("orgaopublico");
		produtor.setNome("Minist�rio Lorem");
		processo.setProdutor(produtor);
		processo.setDescricao("Lorem ipsum dolor sit amet");

		ComponenteDigital arquivo1 = new ComponenteDigital();
		arquivo1.setNome("Arquivo 1");
		
		Hash hash = new Hash();
		hash.setValue(Base64.decode("l9G0iRAn39p9HM9idu/C8tiZMV5LmmLOoS8N/0SbNHs="));
		hash.setAlgoritmo("SHA256");
		arquivo1.setHash(hash);
		arquivo1.setTipoDeConteudo(TipoDeConteudo.TXT);
		arquivo1.setMimeType(MimeType.APPLICATION_PDF);
		arquivo1.setTamanhoEmBytes(14);
		arquivo1.setOrdem(BigInteger.ONE);
		
		DocumentoDoProcesso documento1 = new DocumentoDoProcesso();
		
		documento1.getComponenteDigital().add(arquivo1);
		
		documento1.setDescricao("Lorem ipsum dolor sit amet");
		documento1.setRetirado(false);
		documento1.setOrdem(BigInteger.ONE);
		documento1.setNivelDeSigilo(BigInteger.ONE);
		
		documento1.setProdutor(produtor);
		
		documento1.setDataHoraDeProducao(DatatypeFactory.newInstance().newXMLGregorianCalendar((GregorianCalendar) Calendar.getInstance()));
		documento1.setDataHoraDeRegistro(DatatypeFactory.newInstance().newXMLGregorianCalendar((GregorianCalendar) Calendar.getInstance()));
		
		Especie especie = new Especie();
		especie.setCodigo("1");
		especie.setNomeNoProdutor("Nome lorem ipsum");
		documento1.setEspecie(especie);
		
		processo.getDocumento().add(documento1);
		
		Interessado interessado1 = new Interessado();
		interessado1.setNome("Jo�o Carlos");
		interessado1.setTipo("fisica");
		processo.getInteressado().add(interessado1);
		
		DadosTramiteDeProcessoCriado resposta = ws.enviarProcesso(dadosEnvio);
		
		System.out.println("Tr�mite criado com sucesso. IDT: " + resposta.getIDT());
		
		return resposta;
	}
	
}
